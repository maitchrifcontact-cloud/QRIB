import { useState } from 'react';
import { SafeAreaView, View, Text, StyleSheet, Pressable, ScrollView, TextInput } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const services = [
  ['كهرباء','flash-outline','كهربائيين محترفين'],
  ['سباكة','water-outline','إصلاحات السباكة'],
  ['نظافة','sparkles-outline','نظافة المنازل والمكاتب'],
  ['صيانة','construct-outline','صيانة وإصلاح'],
  ['نقل','car-outline','النقل والتوصيل'],
  ['دهان','color-palette-outline','صباغة وديكور'],
  ['حدائق','leaf-outline','حدائق وتشذيب'],
  ['أخرى','ellipsis-horizontal-circle-outline','خدمات متنوعة'],
];

export default function Home() {
  const [tab,setTab]=useState('home');
  const [search,setSearch]=useState('');
  const [selected,setSelected]=useState(null);
  const [requests,setRequests]=useState([]);
  const [note,setNote]=useState('');

  const filtered=services.filter(x=>x[0].includes(search.trim()) || x[2].includes(search.trim()));

  if(tab==='requests') return <Screen title="طلباتي" onBack={()=>setTab('home')}>
    <ScrollView contentContainerStyle={{paddingBottom:100}}>
      {requests.length===0 ? <View style={styles.empty}>
        <Ionicons name="clipboard-outline" size={54} color="#17324D"/>
        <Text style={styles.emptyTitle}>مازال ما عندك حتى طلب</Text>
        <Text style={styles.muted}>اختار خدمة من الصفحة الرئيسية وابدأ الطلب.</Text>
      </View> : requests.map((r,i)=><View key={i} style={styles.requestCard}>
        <View style={styles.requestTop}><Text style={styles.status}>جديد</Text><Text style={styles.requestName}>{r.name}</Text></View>
        <Text style={styles.muted}>{r.note || 'بدون تفاصيل إضافية'}</Text>
        <Text style={styles.dateText}>تم إرسال الطلب الآن</Text>
      </View>)}
    </ScrollView>
  </Screen>;

  if(tab==='profile') return <Screen title="حسابي" onBack={()=>setTab('home')}>
    <View style={styles.profileCard}>
      <View style={styles.avatar}><Ionicons name="person" size={32} color="#fff"/></View>
      <Text style={styles.profileName}>مرحبا بك</Text>
      <Text style={styles.muted}>حسابك في قريب</Text>
    </View>
    {['معلومات الحساب','العناوين','الإشعارات','المساعدة والتواصل'].map((x,i)=>
      <Pressable key={x} style={styles.menu}><Ionicons name={['person-outline','location-outline','notifications-outline','help-circle-outline'][i]} size={22} color="#17324D"/><Text style={styles.menuText}>{x}</Text><Ionicons name="chevron-back" size={20} color="#999"/></Pressable>
    )}
  </Screen>;

  return <SafeAreaView style={styles.safe}>
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.top}>
        <View>
          <Text style={styles.brand}>قريب</Text>
          <Text style={styles.subtitle}>الخدمة اللي كتقلب عليها قريبة ليك</Text>
        </View>
        <Pressable style={styles.bell}><Ionicons name="notifications-outline" size={24} color="#17324D"/></Pressable>
      </View>

      <View style={styles.search}>
        <Ionicons name="search" size={21} color="#777"/>
        <TextInput value={search} onChangeText={setSearch} placeholder="قلب على خدمة..." placeholderTextColor="#888" style={styles.input}/>
      </View>

      <View style={styles.hero}>
        <View style={{flex:1}}>
          <Text style={styles.heroTitle}>شنو محتاج اليوم؟</Text>
          <Text style={styles.heroText}>لقا المهني المناسب وطلب الخدمة بسهولة.</Text>
        </View>
        <Ionicons name="home-outline" size={54} color="#fff"/>
      </View>

      <Text style={styles.section}>الخدمات</Text>
      <View style={styles.grid}>
        {filtered.map(([name,icon,desc])=>
          <Pressable key={name} style={styles.service} onPress={()=>setSelected({name,desc})}>
            <View style={styles.iconBox}><Ionicons name={icon} size={27} color="#17324D"/></View>
            <Text style={styles.serviceName}>{name}</Text>
            <Text style={styles.serviceDesc}>{desc}</Text>
          </Pressable>
        )}
      </View>

      <View style={styles.how}>
        <Text style={styles.section}>كيفاش خدام؟</Text>
        {[
          ['1','اختار الخدمة','اختار الخدمة اللي محتاج.'],
          ['2','رسل الطلب','دخل المعلومات وحدد الوقت.'],
          ['3','خدم مع مهني','تواصل مع المهني وكمل الخدمة.']
        ].map(([n,t,d])=><View style={styles.step} key={n}>
          <View style={styles.num}><Text style={styles.numText}>{n}</Text></View>
          <View style={{flex:1}}><Text style={styles.stepTitle}>{t}</Text><Text style={styles.muted}>{d}</Text></View>
        </View>)}
      </View>
    </ScrollView>

    {selected && <View style={styles.modalWrap}>
      <View style={styles.modal}>
        <Pressable style={styles.close} onPress={()=>setSelected(null)}><Ionicons name="close" size={24}/></Pressable>
        <View style={styles.bigIcon}><Ionicons name="construct-outline" size={38} color="#17324D"/></View>
        <Text style={styles.modalTitle}>طلب خدمة {selected.name}</Text>
        <Text style={styles.muted}>{selected.desc}</Text>
        <TextInput placeholder="شنو بغيتي بالضبط؟" multiline value={note} onChangeText={setNote} style={styles.note}/>
        <Pressable style={styles.primary} onPress={()=>{setRequests(prev=>[{name:selected.name,note:note.trim()},...prev]);setNote('');setSelected(null);setTab('requests')}}><Text style={styles.primaryText}>إرسال الطلب</Text></Pressable>
      </View>
    </View>}

    <View style={styles.nav}>
      <Nav icon="home" label="الرئيسية" active={tab==='home'} onPress={()=>setTab('home')}/>
      <Nav icon="clipboard-outline" label="طلباتي" active={tab==='requests'} onPress={()=>setTab('requests')}/>
      <Nav icon="person-outline" label="حسابي" active={tab==='profile'} onPress={()=>setTab('profile')}/>
    </View>
  </SafeAreaView>
}

function Nav({icon,label,active,onPress}){return <Pressable onPress={onPress} style={styles.navItem}><Ionicons name={icon} size={24} color={active?'#17324D':'#999'}/><Text style={[styles.navText,active&&{color:'#17324D'}]}>{label}</Text></Pressable>}
function Screen({title,onBack,children}){return <SafeAreaView style={styles.safe}><View style={styles.screen}><Pressable onPress={onBack} style={styles.back}><Ionicons name="arrow-forward" size={24}/><Text style={styles.screenTitle}>{title}</Text></Pressable>{children}</View><View style={styles.nav}><Nav icon="home-outline" label="الرئيسية" active={false} onPress={onBack}/><Nav icon="clipboard-outline" label="طلباتي" active={title==='طلباتي'} onPress={()=>{}}/><Nav icon="person-outline" label="حسابي" active={title==='حسابي'} onPress={()=>{}}/></View></SafeAreaView>}

const styles=StyleSheet.create({
 safe:{flex:1,backgroundColor:'#F7F8FA'},container:{padding:20,paddingBottom:100},
 top:{flexDirection:'row-reverse',alignItems:'center',justifyContent:'space-between',marginBottom:18},brand:{fontSize:34,fontWeight:'800',color:'#17324D',textAlign:'right'},subtitle:{color:'#777',marginTop:3,textAlign:'right'},bell:{backgroundColor:'#fff',padding:11,borderRadius:14},
 search:{height:50,backgroundColor:'#fff',borderRadius:15,flexDirection:'row-reverse',alignItems:'center',paddingHorizontal:14,marginBottom:16},input:{flex:1,textAlign:'right',fontSize:15,paddingHorizontal:9},
 hero:{backgroundColor:'#17324D',borderRadius:22,padding:20,flexDirection:'row-reverse',alignItems:'center',marginBottom:22},heroTitle:{color:'#fff',fontSize:23,fontWeight:'800',textAlign:'right'},heroText:{color:'#DDE7F0',marginTop:7,textAlign:'right',lineHeight:21},
 section:{fontSize:21,fontWeight:'800',color:'#17324D',textAlign:'right',marginBottom:12},grid:{flexDirection:'row-reverse',flexWrap:'wrap',justifyContent:'space-between'},
 service:{backgroundColor:'#fff',width:'48%',borderRadius:18,padding:14,marginBottom:12,minHeight:145},iconBox:{width:48,height:48,borderRadius:14,backgroundColor:'#EEF3F7',alignItems:'center',justifyContent:'center',marginBottom:10,alignSelf:'flex-end'},serviceName:{fontSize:17,fontWeight:'800',color:'#17324D',textAlign:'right'},serviceDesc:{fontSize:12,color:'#777',textAlign:'right',marginTop:4},
 how:{marginTop:10},step:{backgroundColor:'#fff',borderRadius:16,padding:14,flexDirection:'row-reverse',alignItems:'center',marginBottom:9},num:{width:38,height:38,borderRadius:19,backgroundColor:'#17324D',alignItems:'center',justifyContent:'center',marginLeft:12},numText:{color:'#fff',fontWeight:'800'},stepTitle:{fontWeight:'800',color:'#17324D',textAlign:'right',fontSize:16},muted:{color:'#777',textAlign:'right',marginTop:3},
 nav:{position:'absolute',bottom:0,left:0,right:0,height:72,backgroundColor:'#fff',borderTopWidth:1,borderTopColor:'#eee',flexDirection:'row-reverse',justifyContent:'space-around',alignItems:'center'},navItem:{alignItems:'center',justifyContent:'center',minWidth:80},navText:{fontSize:12,color:'#999',marginTop:3},
 modalWrap:{position:'absolute',top:0,bottom:72,left:0,right:0,backgroundColor:'rgba(0,0,0,.35)',justifyContent:'flex-end'},modal:{backgroundColor:'#fff',borderTopLeftRadius:28,borderTopRightRadius:28,padding:22},close:{alignSelf:'flex-start'},bigIcon:{width:64,height:64,borderRadius:20,backgroundColor:'#EEF3F7',alignItems:'center',justifyContent:'center',alignSelf:'center'},modalTitle:{fontSize:22,fontWeight:'800',color:'#17324D',textAlign:'center',marginTop:12},note:{height:100,borderWidth:1,borderColor:'#ddd',borderRadius:14,padding:12,textAlign:'right',marginTop:16,textAlignVertical:'top'},primary:{backgroundColor:'#17324D',height:52,borderRadius:15,alignItems:'center',justifyContent:'center',marginTop:14},primaryText:{color:'#fff',fontSize:17,fontWeight:'800'},
 screen:{flex:1,padding:20},back:{flexDirection:'row-reverse',alignItems:'center',gap:10,marginBottom:25},screenTitle:{fontSize:26,fontWeight:'800',color:'#17324D'},empty:{flex:1,alignItems:'center',justifyContent:'center',paddingBottom:120},emptyTitle:{fontSize:20,fontWeight:'800',color:'#17324D',marginTop:14},profileCard:{backgroundColor:'#fff',borderRadius:22,padding:22,alignItems:'center',marginBottom:14},avatar:{width:70,height:70,borderRadius:35,backgroundColor:'#17324D',alignItems:'center',justifyContent:'center'},profileName:{fontSize:21,fontWeight:'800',color:'#17324D',marginTop:10},menu:{backgroundColor:'#fff',padding:18,borderRadius:16,flexDirection:'row-reverse',alignItems:'center',gap:12,marginBottom:9},menuText:{flex:1,textAlign:'right',fontSize:16,color:'#17324D'},
 requestCard:{backgroundColor:'#fff',borderRadius:18,padding:17,marginBottom:10},requestTop:{flexDirection:'row-reverse',alignItems:'center',justifyContent:'space-between',marginBottom:7},requestName:{fontSize:18,fontWeight:'800',color:'#17324D',textAlign:'right'},status:{backgroundColor:'#EEF3F7',color:'#17324D',paddingHorizontal:10,paddingVertical:5,borderRadius:10,fontWeight:'800'},dateText:{color:'#999',fontSize:12,textAlign:'right',marginTop:10}
});